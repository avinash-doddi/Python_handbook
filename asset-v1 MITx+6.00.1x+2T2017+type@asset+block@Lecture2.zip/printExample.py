# -*- coding: utf-8 -*-
"""
Created on Wed Jun  8 11:14:34 2016

@author: ericgrimson
"""


x = 1
print(x)
x_str = str(x)
print("my fav num is", x, ".", "x =", x)
print("my fav num is " + x_str + ". " + "x = " + x_str)
